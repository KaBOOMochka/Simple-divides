--[[ Basically, only the first divide in the chain is doing something,
the others only need for id's. While deck is not empty, divide trying to find a relevant
target, by adding every spell to the hand and checking it.
If they find a divide, they will write their id (type of divide) in the divide_counts.
If they find something different, they'll check its charges and recursion and then, if its 
relevant, they'll save it in the "data", if it is not, they'll discard it. Then, they save
spell delay and recharge time to reset them in the end. Then divides starts copying.
They take every divide from divide_counts and multiply it all together, calculating
damage and explosion reduction, as well as total copies number. If divide is off its limit, then 
it only multiply it by 1. Then they call the target spell myltiple times, and if the target
is a modifier, multicast or a passive, or it is one of the spells, that draw, but not in these
types (like some of the spells from utility, but not a trigger. Hell, no, I'll do that every
trigger calls something!), THEN the divide will draw once.

And... I think its hard to make this compatible with wand dbg, so be like that..

And yeah, Mu, Phi and Sigma work pretty bad with this divides, but I have no idea how to
stop them from calling something.]]--


local Divide_ids = {"DIVIDE_2", "DIVIDE_3","DIVIDE_4","DIVIDE_10"}
local Divide_limits = {5, 4, 4, 3}
local dmg_reduction = {0.2, 0.4, 0.6, 1.5}
local expl_reduction = {5.0, 10.0, 20.0, 40.0}
local divide_values = {"2","3","4","10"}
local spells_that_draw = {"BLOOD_MAGIC","I_SHOT","Y_SHOT","W_SHOT","T_SHOT","QUAD_SHOT","PENTA_SHOT","HEXA_SHOT","BLOOD_TO_POWER","MONEY_MAGIC"}
local is_mod = ModIsEnabled("InfIteration")
local infiterat_sett = false
local damage_pen_sett = false
local expl_pen_sett = false
if is_mod then
	infiterat_sett = ModSettingGet('InfIteration.div_no_limit')
	damage_pen_sett = ModSettingGet('InfIteration.dmg_penalty')
	expl_pen_sett = ModSettingGet('InfIteration.expl_rad_penalty')
end
local Simple_divides = {
	{
		id = "DIVIDE_2",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 20
			local divide_counts = {}
			local data = {}
			divide_counts[1] = 1         -- first div is id 1 (which id D2)
			local recur = 0
			while #deck > 0 do
				local t = deck[1]
				table.insert( hand, t )
				table.remove( deck, 1 )
				local div_found = 0
				for div=1, #Divide_ids do -- check every divide id
					if hand[#hand]["id"] == Divide_ids[div] then  -- compare it to the last hand
						div_found = div  -- save relevant divide id
					end
				end
				if div_found == 0 then -- not a divide
					local rec = check_recursion( hand[#hand], recursion_level )
					if ( rec > -1 ) and ( ( hand[#hand]["uses_remaining"] == nil ) or (hand[#hand]["uses_remaining"] ~= 0 ) ) then
					-- spell is relevant
						data = hand[#hand]
						recur = rec
			break
					else
						local g = hand[#hand]
						table.insert( discarded, g )
						table.remove( hand, #hand )
					end
				else -- if divide is found
					table.insert(divide_counts, div_found )
				end
			end

			local firerate = c.fire_rate_wait     -- save spell delay and recharge time
			local reload = current_reload_time

			
			local damage_count = 0
			local expl_count = 0
			local how_many_copies = 1
			local dmg_penalty = 1
			local expl_penalty = 1
			iter_lim = function (key, id)
				if Divide_limits[id] > key or infiterat_sett then
					return(divide_values[id])
				else
					return(1)
				end
				
			end
			for key, divid in pairs(divide_counts) do
				damage_count = damage_count + dmg_reduction[divid]*dmg_penalty
				expl_count = expl_count + expl_reduction[divid]*expl_penalty
				how_many_copies = how_many_copies * iter_lim(key, divid) -- multiply every divide (divide id in divide_values)
				dmg_penalty = dmg_penalty * divide_values[divid]
				expl_penalty = expl_penalty * divide_values[divid]
			end
			if not expl_pen_sett then
				c.explosion_radius = c.explosion_radius - expl_count
				if (c.explosion_radius < 0) then
					c.explosion_radius = 0
				end
			end
			if not damage_pen_sett then
				c.damage_projectile_add = c.damage_projectile_add - damage_count
			end
			if ( data["id"] ~= nil) then
				for e=1, how_many_copies do
					dont_draw_actions = true
					data.action(recur)
				end
				dont_draw_actions = false
			end
			local draw_or_not = 0
			for y=1, #spells_that_draw do
				if data["type"] == ACTION_TYPE_DRAW_MANY or data["type"] == ACTION_TYPE_MODIFIER or data["type"] == ACTION_TYPE_PASSIVE or data["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
			end
			c.fire_rate_wait = firerate
			current_reload_time = reload
			c.pattern_degrees = 5
			if draw_or_not >= 1 then
				draw_actions(1, true)
			end
		end
	},
	{
		id = "DIVIDE_3",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 35
			local divide_counts = {}
			local data = {}
			divide_counts[1] = 2         -- first div is id 1 (which id D3)
			local recur = 0
			while #deck > 0 do
				local t = deck[1]
				table.insert( hand, t )
				table.remove( deck, 1 )
				local div_found = 0
				for div=1, #Divide_ids do -- check every divide id
					if hand[#hand]["id"] == Divide_ids[div] then  -- compare it to the last hand
						div_found = div  -- save relevant divide id
					end
				end
				if div_found == 0 then -- not a divide
					local rec = check_recursion( hand[#hand], recursion_level )
					if ( rec > -1 ) and ( ( hand[#hand]["uses_remaining"] == nil ) or (hand[#hand]["uses_remaining"] ~= 0 ) ) then
					-- spell is relevant
						data = hand[#hand]
						recur = rec
			break
					else
						local g = hand[#hand]
						table.insert( discarded, g )
						table.remove( hand, #hand )
					end
				else -- if divide is found
					table.insert(divide_counts, div_found )
				end
			end

			local firerate = c.fire_rate_wait     -- save spell delay and recharge time
			local reload = current_reload_time

			
			local damage_count = 0
			local expl_count = 0
			local how_many_copies = 1
			local dmg_penalty = 1
			local expl_penalty = 1
			iter_lim = function (key, id)
				if Divide_limits[id] > key or infiterat_sett then
					return(divide_values[id])
				else
					return(1)
				end
				
			end
			for key, divid in pairs(divide_counts) do
				damage_count = damage_count + dmg_reduction[divid]*dmg_penalty
				expl_count = expl_count + expl_reduction[divid]*expl_penalty
				how_many_copies = how_many_copies * iter_lim(key, divid) -- multiply every divide (divide id in divide_values)
				dmg_penalty = dmg_penalty * divide_values[divid]
				expl_penalty = expl_penalty * divide_values[divid]
			end
			if not expl_pen_sett then
				c.explosion_radius = c.explosion_radius - expl_count
				if (c.explosion_radius < 0) then
					c.explosion_radius = 0
				end
			end
			if not damage_pen_sett then
				c.damage_projectile_add = c.damage_projectile_add - damage_count
			end
			if ( data["id"] ~= nil) then
				for e=1, how_many_copies do
					dont_draw_actions = true
					data.action(recur)
				end
				dont_draw_actions = false
			end
			local draw_or_not = 0
			for y=1, #spells_that_draw do
				if data["type"] == ACTION_TYPE_DRAW_MANY or data["type"] == ACTION_TYPE_MODIFIER or data["type"] == ACTION_TYPE_PASSIVE or data["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
			end
			c.fire_rate_wait = firerate
			current_reload_time = reload
			c.pattern_degrees = 5
			if draw_or_not >= 1 then
				draw_actions(1, true)
			end
		end
	},{
		id = "DIVIDE_4",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 50
			local divide_counts = {}
			local data = {}
			divide_counts[1] = 3         -- first div is id 1 (which id D4)
			local recur = 0
			while #deck > 0 do
				local t = deck[1]
				table.insert( hand, t )
				table.remove( deck, 1 )
				local div_found = 0
				for div=1, #Divide_ids do -- check every divide id
					if hand[#hand]["id"] == Divide_ids[div] then  -- compare it to the last hand
						div_found = div  -- save relevant divide id
					end
				end
				if div_found == 0 then -- not a divide
					local rec = check_recursion( hand[#hand], recursion_level )
					if ( rec > -1 ) and ( ( hand[#hand]["uses_remaining"] == nil ) or (hand[#hand]["uses_remaining"] ~= 0 ) ) then
					-- spell is relevant
						data = hand[#hand]
						recur = rec
			break
					else
						local g = hand[#hand]
						table.insert( discarded, g )
						table.remove( hand, #hand )
					end
				else -- if divide is found
					table.insert(divide_counts, div_found )
				end
			end

			local firerate = c.fire_rate_wait     -- save spell delay and recharge time
			local reload = current_reload_time

			
			local damage_count = 0
			local expl_count = 0
			local how_many_copies = 1
			local dmg_penalty = 1
			local expl_penalty = 1
			iter_lim = function (key, id)
				if Divide_limits[id] > key or infiterat_sett then
					return(divide_values[id])
				else
					return(1)
				end
				
			end
			for key, divid in pairs(divide_counts) do
				damage_count = damage_count + dmg_reduction[divid]*dmg_penalty
				expl_count = expl_count + expl_reduction[divid]*expl_penalty
				how_many_copies = how_many_copies * iter_lim(key, divid) -- multiply every divide (divide id in divide_values)
				dmg_penalty = dmg_penalty * divide_values[divid]
				expl_penalty = expl_penalty * divide_values[divid]
			end
			if not expl_pen_sett then
				c.explosion_radius = c.explosion_radius - expl_count
				if (c.explosion_radius < 0) then
					c.explosion_radius = 0
				end
			end
			if not damage_pen_sett then
				c.damage_projectile_add = c.damage_projectile_add - damage_count
			end
			if ( data["id"] ~= nil) then
				for e=1, how_many_copies do
					dont_draw_actions = true
					data.action(recur)
				end
				dont_draw_actions = false
			end
			local draw_or_not = 0
			for y=1, #spells_that_draw do
				if data["type"] == ACTION_TYPE_DRAW_MANY or data["type"] == ACTION_TYPE_MODIFIER or data["type"] == ACTION_TYPE_PASSIVE or data["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
			end
			c.fire_rate_wait = firerate
			current_reload_time = reload
			c.pattern_degrees = 5
			if draw_or_not >= 1 then
				draw_actions(1, true)
			end
		end
	},
	{
		id = "DIVIDE_10",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 80
			current_reload_time = current_reload_time + 20
			local divide_counts = {}
			local data = {}
			divide_counts[1] = 4         -- first div is id 1 (which id D10)
			local recur = 0
			while #deck > 0 do
				local t = deck[1]
				table.insert( hand, t )
				table.remove( deck, 1 )
				local div_found = 0
				for div=1, #Divide_ids do -- check every divide id
					if hand[#hand]["id"] == Divide_ids[div] then  -- compare it to the last hand
						div_found = div  -- save relevant divide id
					end
				end
				if div_found == 0 then -- not a divide
					local rec = check_recursion( hand[#hand], recursion_level )
					if ( rec > -1 ) and ( ( hand[#hand]["uses_remaining"] == nil ) or (hand[#hand]["uses_remaining"] ~= 0 ) ) then
					-- spell is relevant
						data = hand[#hand]
						recur = rec
			break
					else
						local g = hand[#hand]
						table.insert( discarded, g )
						table.remove( hand, #hand )
					end
				else -- if divide is found
					table.insert(divide_counts, div_found )
				end
			end

			local firerate = c.fire_rate_wait     -- save spell delay and recharge time
			local reload = current_reload_time

			
			local damage_count = 0
			local expl_count = 0
			local how_many_copies = 1
			local dmg_penalty = 1
			local expl_penalty = 1
			iter_lim = function (key, id)
				if Divide_limits[id] > key or infiterat_sett then
					return(divide_values[id])
				else
					return(1)
				end
				
			end
			for key, divid in pairs(divide_counts) do
				damage_count = damage_count + dmg_reduction[divid]*dmg_penalty
				expl_count = expl_count + expl_reduction[divid]*expl_penalty
				how_many_copies = how_many_copies * iter_lim(key, divid) -- multiply every divide (divide id in divide_values)
				dmg_penalty = dmg_penalty * divide_values[divid]
				expl_penalty = expl_penalty * divide_values[divid]
			end
			if not expl_pen_sett then
				c.explosion_radius = c.explosion_radius - expl_count
				if (c.explosion_radius < 0) then
					c.explosion_radius = 0
				end
			end
			if not damage_pen_sett then
				c.damage_projectile_add = c.damage_projectile_add - damage_count
			end
			if ( data["id"] ~= nil) then
				for e=1, how_many_copies do
					dont_draw_actions = true
					data.action(recur)
				end
				dont_draw_actions = false
			end
			local draw_or_not = 0
			for y=1, #spells_that_draw do
				if data["type"] == ACTION_TYPE_DRAW_MANY or data["type"] == ACTION_TYPE_MODIFIER or data["type"] == ACTION_TYPE_PASSIVE or data["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
			end
			c.fire_rate_wait = firerate
			current_reload_time = reload
			c.pattern_degrees = 5
			if draw_or_not >= 1 then
				draw_actions(1, true)
			end
		end
	}
}
-- Change divides
for i=1, #actions do
	for d=1, #Simple_divides do
		if Simple_divides[d]["id"] == actions[i]["id"] then
			actions[i]["action"] = Simple_divides[d]["action"]
		end
	end
end