--[[ Basically, only the first divide in the chain is doing something,
the others only need for id's. While deck is not empty, divide trying to find a relevant
target, by adding every spell to the hand and checking it.
If they find a divide, they will write their id (type of divide) in the divide_counts.
If they find something different, they'll check its charges and recursion and then, if its 
relevant, they'll save it in the "data", if it is not, they'll discard it. Then, they save
spell delay and recharge time to reset them in the end. Then divides starts copying.
They take every divide from divide_counts and multiply it all together, calculating
damage and explosion reduction, as well as total copies number. If divide is off its limit, then 
it only multiply it by 1. Then they call the target spell myltiple times, and if the target
is a modifier, multicast or a passive, or it is one of the spells, that draw, but not in these
types (like some of the spells from utility, but not a trigger. Hell, no, I'll do that every
trigger calls something!), THEN the divide will draw once.

And... I think its hard to make this compatible with wand dbg, so be like that..

And yeah, Mu, Phi and Sigma work pretty bad with this divides, but I have no idea how to
stop them from calling something.]]--


local Divide_ids = {"DIVIDE_2", "DIVIDE_3","DIVIDE_4","DIVIDE_10"}
local Divide_limits = {5, 4, 4, 3}
local dmg_reduction = {0.2, 0.4, 0.6, 1.5}
local expl_reduction = {5.0, 10.0, 20.0, 40.0}
local divide_values = {"2","3","4","10"}
local spells_that_draw = {"BLOOD_MAGIC","I_SHOT","Y_SHOT","W_SHOT","T_SHOT","QUAD_SHOT","PENTA_SHOT","HEXA_SHOT","BLOOD_TO_POWER","MONEY_MAGIC","MU"}
local is_mod = ModIsEnabled("InfIteration")
local infiterat_sett = false
local damage_pen_sett = false
local expl_pen_sett = false
if is_mod then
	infiterat_sett = ModSettingGet('InfIteration.div_no_limit')
	damage_pen_sett = ModSettingGet('InfIteration.dmg_penalty')
	expl_pen_sett = ModSettingGet('InfIteration.expl_rad_penalty')
end
local Simple_divides = {
	{
		id = "DIVIDE_2",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 20
			local divide_counts = {}
			local data = {}
			divide_counts[1] = 1         -- first div id is 1 (which id D2)
			local recur = 0
			local datagamma = {}
			local dataalfa = {}
			while #deck > 0 do
				local t = deck[1]
				table.insert( hand, t )
				table.remove( deck, 1 )
				local div_found = 0
				for div=1, #Divide_ids do -- check every divide id
					if hand[#hand]["id"] == Divide_ids[div] then  -- compare it to the last hand
						div_found = div  -- save relevant divide id
					end
				end
				if div_found == 0 then -- not a divide
					local rec = check_recursion( hand[#hand], recursion_level )
					if ( rec > -1 ) and ( ( hand[#hand]["uses_remaining"] == nil ) or (hand[#hand]["uses_remaining"] ~= 0 ) ) then
					-- spell is relevant
						data = hand[#hand]
						recur = rec
						if data["id"] == "GAMMA" then
							if ( #deck > 0 ) then
								datagamma = deck[#deck]
							elseif ( #hand > 0 ) then
								datagamma = hand[#hand]
							else
								datagamma = nil
							end
						end
						if ( #discarded > 0 ) then
							dataalfa = discarded[1]
						elseif ( #hand > 0 ) then
							dataalfa = hand[1]
						elseif ( #deck > 0 ) then
							dataalfa = deck[1]
						else
							dataalfa = nil
						end
			break
					else
						local g = hand[#hand]
						table.insert( discarded, g )
						table.remove( hand, #hand )
					end
				else -- if divide is found
					table.insert(divide_counts, div_found )
				end
			end

			local firerate = c.fire_rate_wait     -- save spell delay and recharge time
			local reload = current_reload_time

			
			local damage_count = 0
			local expl_count = 0
			local how_many_copies = 1
			local dmg_penalty = 1
			local expl_penalty = 1
			iter_lim = function (key, id)
				if Divide_limits[id] > key or infiterat_sett then
					return(divide_values[id])
				else
					return(1)
				end
				
			end
			for key, divid in pairs(divide_counts) do
				damage_count = damage_count + dmg_reduction[divid]*dmg_penalty
				expl_count = expl_count + expl_reduction[divid]*expl_penalty
				how_many_copies = how_many_copies * iter_lim(key, divid) -- multiply every divide (divide id in divide_values)
				dmg_penalty = dmg_penalty * divide_values[divid]
				expl_penalty = expl_penalty * divide_values[divid]
			end
			if not expl_pen_sett then
				c.explosion_radius = c.explosion_radius - expl_count
				if (c.explosion_radius < 0) then
					c.explosion_radius = 0
				end
			end
			if not damage_pen_sett then
				c.damage_projectile_add = c.damage_projectile_add - damage_count
			end
			if ( data["id"] ~= nil) then
				for e=1, how_many_copies do
					dont_draw_actions = true
					data.action(recur, 1)
				end
				dont_draw_actions = false
			end
			local draw_or_not = 0
			for y=1, #spells_that_draw do
				if data["type"] == ACTION_TYPE_DRAW_MANY or data["type"] == ACTION_TYPE_MODIFIER or data["type"] == ACTION_TYPE_PASSIVE or data["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
			end
			if datagamma ~= nil then
				for y=1, #spells_that_draw do
				if datagamma["type"] == ACTION_TYPE_DRAW_MANY or datagamma["type"] == ACTION_TYPE_MODIFIER or datagamma["type"] == ACTION_TYPE_PASSIVE or datagamma["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If gamma's target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
				end
			end
			if dataalfa ~= nil then
				for y=1, #spells_that_draw do
				if dataalfa["type"] == ACTION_TYPE_DRAW_MANY or dataalfa["type"] == ACTION_TYPE_MODIFIER or dataalfa["type"] == ACTION_TYPE_PASSIVE or dataalfa["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If alfa's target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
				end
			end

		
			if data["type"] == 0 or data["type"] == 1 or data["type"] == 4 then
				if ( data.uses_remaining ~= nil ) and ( data.uses_remaining > 0 ) then
					data.uses_remaining = data.uses_remaining - 1
					
					local reduce_uses = ActionUsesRemainingChanged( data.inventoryitem_id, data.uses_remaining )
					if not reduce_uses then
						data.uses_remaining = data.uses_remaining + 1 -- cancel the reduction  -- idk, thats how it in vanilla and it works
					end
				end
			end
			c.fire_rate_wait = firerate
			current_reload_time = reload
			c.pattern_degrees = 5
			if draw_or_not >= 1 then
				draw_actions(1, true)
			end
		end
	},
	{
		id = "DIVIDE_3",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 35
			local divide_counts = {}
			local data = {}
			divide_counts[1] = 2         -- first div id is 2 (which id D3)
			local recur = 0
			local datagamma = {}
			local dataalfa = {}
			while #deck > 0 do
				local t = deck[1]
				table.insert( hand, t )
				table.remove( deck, 1 )
				local div_found = 0
				for div=1, #Divide_ids do -- check every divide id
					if hand[#hand]["id"] == Divide_ids[div] then  -- compare it to the last hand
						div_found = div  -- save relevant divide id
					end
				end
				if div_found == 0 then -- not a divide
					local rec = check_recursion( hand[#hand], recursion_level )
					if ( rec > -1 ) and ( ( hand[#hand]["uses_remaining"] == nil ) or (hand[#hand]["uses_remaining"] ~= 0 ) ) then
					-- spell is relevant
						data = hand[#hand]
						recur = rec
						if data["id"] == "GAMMA" then
							if ( #deck > 0 ) then
								datagamma = deck[#deck]
							elseif ( #hand > 0 ) then
								datagamma = hand[#hand]
							else
								datagamma = nil
							end
						end
						if ( #discarded > 0 ) then
							dataalfa = discarded[1]
						elseif ( #hand > 0 ) then
							dataalfa = hand[1]
						elseif ( #deck > 0 ) then
							dataalfa = deck[1]
						else
							dataalfa = nil
						end
			break
					else
						local g = hand[#hand]
						table.insert( discarded, g )
						table.remove( hand, #hand )
					end
				else -- if divide is found
					table.insert(divide_counts, div_found )
				end
			end

			local firerate = c.fire_rate_wait     -- save spell delay and recharge time
			local reload = current_reload_time

			
			local damage_count = 0
			local expl_count = 0
			local how_many_copies = 1
			local dmg_penalty = 1
			local expl_penalty = 1
			iter_lim = function (key, id)
				if Divide_limits[id] > key or infiterat_sett then
					return(divide_values[id])
				else
					return(1)
				end
				
			end
			for key, divid in pairs(divide_counts) do
				damage_count = damage_count + dmg_reduction[divid]*dmg_penalty
				expl_count = expl_count + expl_reduction[divid]*expl_penalty
				how_many_copies = how_many_copies * iter_lim(key, divid) -- multiply every divide (divide id in divide_values)
				dmg_penalty = dmg_penalty * divide_values[divid]
				expl_penalty = expl_penalty * divide_values[divid]
			end
			if not expl_pen_sett then
				c.explosion_radius = c.explosion_radius - expl_count
				if (c.explosion_radius < 0) then
					c.explosion_radius = 0
				end
			end
			if not damage_pen_sett then
				c.damage_projectile_add = c.damage_projectile_add - damage_count
			end
			if ( data["id"] ~= nil) then
				for e=1, how_many_copies do
					dont_draw_actions = true
					data.action(recur, 1)
				end
				dont_draw_actions = false
			end
			local draw_or_not = 0
			for y=1, #spells_that_draw do
				if data["type"] == ACTION_TYPE_DRAW_MANY or data["type"] == ACTION_TYPE_MODIFIER or data["type"] == ACTION_TYPE_PASSIVE or data["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
			end
			if datagamma ~= nil then
				for y=1, #spells_that_draw do
				if datagamma["type"] == ACTION_TYPE_DRAW_MANY or datagamma["type"] == ACTION_TYPE_MODIFIER or datagamma["type"] == ACTION_TYPE_PASSIVE or datagamma["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If gamma's target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
				end
			end
			if dataalfa ~= nil then
				for y=1, #spells_that_draw do
				if dataalfa["type"] == ACTION_TYPE_DRAW_MANY or dataalfa["type"] == ACTION_TYPE_MODIFIER or dataalfa["type"] == ACTION_TYPE_PASSIVE or dataalfa["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If alfa's target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
				end
			end
			if data["type"] == 0 or data["type"] == 1 or data["type"] == 4 then
				if ( data.uses_remaining ~= nil ) and ( data.uses_remaining > 0 ) then
					data.uses_remaining = data.uses_remaining - 1
					
					local reduce_uses = ActionUsesRemainingChanged( data.inventoryitem_id, data.uses_remaining )
					if not reduce_uses then
						data.uses_remaining = data.uses_remaining + 1 -- cancel the reduction  -- idk, thats how it in vanilla and it works
					end
				end
			end
			c.fire_rate_wait = firerate
			current_reload_time = reload
			c.pattern_degrees = 5
			if draw_or_not >= 1 then
				draw_actions(1, true)
			end
		end
	},
	{
		id = "DIVIDE_4",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 50
			local divide_counts = {}
			local data = {}
			divide_counts[1] = 3         -- first div id is 3 (which id D4)
			local recur = 0
			local datagamma = {}
			local dataalfa = {}
			while #deck > 0 do
				local t = deck[1]
				table.insert( hand, t )
				table.remove( deck, 1 )
				local div_found = 0
				for div=1, #Divide_ids do -- check every divide id
					if hand[#hand]["id"] == Divide_ids[div] then  -- compare it to the last hand
						div_found = div  -- save relevant divide id
					end
				end
				if div_found == 0 then -- not a divide
					local rec = check_recursion( hand[#hand], recursion_level )
					if ( rec > -1 ) and ( ( hand[#hand]["uses_remaining"] == nil ) or (hand[#hand]["uses_remaining"] ~= 0 ) ) then
					-- spell is relevant
						data = hand[#hand]
						recur = rec
						if data["id"] == "GAMMA" then
							if ( #deck > 0 ) then
								datagamma = deck[#deck]
							elseif ( #hand > 0 ) then
								datagamma = hand[#hand]
							else
								datagamma = nil
							end
						end
						if ( #discarded > 0 ) then
							dataalfa = discarded[1]
						elseif ( #hand > 0 ) then
							dataalfa = hand[1]
						elseif ( #deck > 0 ) then
							dataalfa = deck[1]
						else
							dataalfa = nil
						end
			break
					else
						local g = hand[#hand]
						table.insert( discarded, g )
						table.remove( hand, #hand )
					end
				else -- if divide is found
					table.insert(divide_counts, div_found )
				end
			end

			local firerate = c.fire_rate_wait     -- save spell delay and recharge time
			local reload = current_reload_time

			
			local damage_count = 0
			local expl_count = 0
			local how_many_copies = 1
			local dmg_penalty = 1
			local expl_penalty = 1
			iter_lim = function (key, id)
				if Divide_limits[id] > key or infiterat_sett then
					return(divide_values[id])
				else
					return(1)
				end
				
			end
			for key, divid in pairs(divide_counts) do
				damage_count = damage_count + dmg_reduction[divid]*dmg_penalty
				expl_count = expl_count + expl_reduction[divid]*expl_penalty
				how_many_copies = how_many_copies * iter_lim(key, divid) -- multiply every divide (divide id in divide_values)
				dmg_penalty = dmg_penalty * divide_values[divid]
				expl_penalty = expl_penalty * divide_values[divid]
			end
			if not expl_pen_sett then
				c.explosion_radius = c.explosion_radius - expl_count
				if (c.explosion_radius < 0) then
					c.explosion_radius = 0
				end
			end
			if not damage_pen_sett then
				c.damage_projectile_add = c.damage_projectile_add - damage_count
			end
			if ( data["id"] ~= nil) then
				for e=1, how_many_copies do
					dont_draw_actions = true
					data.action(recur, 1)
				end
				dont_draw_actions = false
			end
			local draw_or_not = 0
			for y=1, #spells_that_draw do
				if data["type"] == ACTION_TYPE_DRAW_MANY or data["type"] == ACTION_TYPE_MODIFIER or data["type"] == ACTION_TYPE_PASSIVE or data["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
			end
			if datagamma ~= nil then
				for y=1, #spells_that_draw do
				if datagamma["type"] == ACTION_TYPE_DRAW_MANY or datagamma["type"] == ACTION_TYPE_MODIFIER or datagamma["type"] == ACTION_TYPE_PASSIVE or datagamma["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If gamma's target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
				end
			end
			if dataalfa ~= nil then
				for y=1, #spells_that_draw do
				if dataalfa["type"] == ACTION_TYPE_DRAW_MANY or dataalfa["type"] == ACTION_TYPE_MODIFIER or dataalfa["type"] == ACTION_TYPE_PASSIVE or dataalfa["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If alfa's target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
				end
			end
			if data["type"] == 0 or data["type"] == 1 or data["type"] == 4 then
				if ( data.uses_remaining ~= nil ) and ( data.uses_remaining > 0 ) then
					data.uses_remaining = data.uses_remaining - 1
					
					local reduce_uses = ActionUsesRemainingChanged( data.inventoryitem_id, data.uses_remaining )
					if not reduce_uses then
						data.uses_remaining = data.uses_remaining + 1 -- cancel the reduction  -- idk, thats how it in vanilla and it works
					end
				end
			end
			c.fire_rate_wait = firerate
			current_reload_time = reload
			c.pattern_degrees = 5
			if draw_or_not >= 1 then
				draw_actions(1, true)
			end
		end
	},
	{
		id = "DIVIDE_10",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 80
			current_reload_time = current_reload_time + 20
			local divide_counts = {}
			local data = {}
			divide_counts[1] = 4         -- first div id is 4 (which id D10)
			local recur = 0
			local datagamma = {}
			local dataalfa = {}
			while #deck > 0 do
				local t = deck[1]
				table.insert( hand, t )
				table.remove( deck, 1 )
				local div_found = 0
				for div=1, #Divide_ids do -- check every divide id
					if hand[#hand]["id"] == Divide_ids[div] then  -- compare it to the last hand
						div_found = div  -- save relevant divide id
					end
				end
				if div_found == 0 then -- not a divide
					local rec = check_recursion( hand[#hand], recursion_level )
					if ( rec > -1 ) and ( ( hand[#hand]["uses_remaining"] == nil ) or (hand[#hand]["uses_remaining"] ~= 0 ) ) then
					-- spell is relevant
						data = hand[#hand]
						recur = rec
						if data["id"] == "GAMMA" then
							if ( #deck > 0 ) then
								datagamma = deck[#deck]
							elseif ( #hand > 0 ) then
								datagamma = hand[#hand]
							else
								datagamma = nil
							end
						end
						if ( #discarded > 0 ) then
							dataalfa = discarded[1]
						elseif ( #hand > 0 ) then
							dataalfa = hand[1]
						elseif ( #deck > 0 ) then
							dataalfa = deck[1]
						else
							dataalfa = nil
						end
			break
					else
						local g = hand[#hand]
						table.insert( discarded, g )
						table.remove( hand, #hand )
					end
				else -- if divide is found
					table.insert(divide_counts, div_found )
				end
			end

			local firerate = c.fire_rate_wait     -- save spell delay and recharge time
			local reload = current_reload_time

			
			local damage_count = 0
			local expl_count = 0
			local how_many_copies = 1
			local dmg_penalty = 1
			local expl_penalty = 1
			iter_lim = function (key, id)
				if Divide_limits[id] > key or infiterat_sett then
					return(divide_values[id])
				else
					return(1)
				end
				
			end
			for key, divid in pairs(divide_counts) do
				damage_count = damage_count + dmg_reduction[divid]*dmg_penalty
				expl_count = expl_count + expl_reduction[divid]*expl_penalty
				how_many_copies = how_many_copies * iter_lim(key, divid) -- multiply every divide (divide id in divide_values)
				dmg_penalty = dmg_penalty * divide_values[divid]
				expl_penalty = expl_penalty * divide_values[divid]
			end
			if not expl_pen_sett then
				c.explosion_radius = c.explosion_radius - expl_count
				if (c.explosion_radius < 0) then
					c.explosion_radius = 0
				end
			end
			if not damage_pen_sett then
				c.damage_projectile_add = c.damage_projectile_add - damage_count
			end
			if ( data["id"] ~= nil) then
				for e=1, how_many_copies do
					dont_draw_actions = true
					data.action(recur, 1)
				end
				dont_draw_actions = false
			end
			local draw_or_not = 0
			for y=1, #spells_that_draw do
				if data["type"] == ACTION_TYPE_DRAW_MANY or data["type"] == ACTION_TYPE_MODIFIER or data["type"] == ACTION_TYPE_PASSIVE or data["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
			end
			if datagamma ~= nil then
				for y=1, #spells_that_draw do
				if datagamma["type"] == ACTION_TYPE_DRAW_MANY or datagamma["type"] == ACTION_TYPE_MODIFIER or datagamma["type"] == ACTION_TYPE_PASSIVE or datagamma["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If gamma's target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
				end
			end
			if dataalfa ~= nil then
				for y=1, #spells_that_draw do
				if dataalfa["type"] == ACTION_TYPE_DRAW_MANY or dataalfa["type"] == ACTION_TYPE_MODIFIER or dataalfa["type"] == ACTION_TYPE_PASSIVE or dataalfa["id"] == spells_that_draw[y] then
					draw_or_not = draw_or_not + 1  -- If alfa's target spell is a modifier, passive or multicast (but not a trigger) then draw 1
				end
				end
			end
			if data["type"] == 0 or data["type"] == 1 or data["type"] == 4 then
				if ( data.uses_remaining ~= nil ) and ( data.uses_remaining > 0 ) then
					data.uses_remaining = data.uses_remaining - 1
					
					local reduce_uses = ActionUsesRemainingChanged( data.inventoryitem_id, data.uses_remaining )
					if not reduce_uses then
						data.uses_remaining = data.uses_remaining + 1 -- cancel the reduction  -- idk, thats how it in vanilla and it works
					end
				end
			end
			c.fire_rate_wait = firerate
			current_reload_time = reload
			c.pattern_degrees = 5
			if draw_or_not >= 1 then
				draw_actions(1, true)
			end
		end
	},
	{
		id          = "MU",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 50
			
			local firerate = c.fire_rate_wait
			local reload = current_reload_time
			local mana_ = mana
			
			if ( discarded ~= nil ) then
				for i,data in ipairs( discarded ) do
					local rec = check_recursion( data, recursion_level )
					if ( data ~= nil ) and ( data.type == 2 ) and ( rec > -1 ) then
						dont_draw_actions = true
						data.action( rec )
						dont_draw_actions = false
					end
				end
			end
			
			if ( hand ~= nil ) then
				for i,data in ipairs( hand ) do
					local rec = check_recursion( data, recursion_level )
					if ( data ~= nil ) and ( data.type == 2 ) and ( rec > -1 ) then
						dont_draw_actions = true
						data.action( rec )
						dont_draw_actions = false
					end
				end
			end
			
			if ( deck ~= nil ) then
				for i,data in ipairs( deck ) do
					local rec = check_recursion( data, recursion_level )
					if ( data ~= nil ) and ( data.type == 2 ) and ( rec > -1 ) then
						dont_draw_actions = true
						data.action( rec )
						dont_draw_actions = false
					end
				end
			end
			
			c.fire_rate_wait = firerate
			current_reload_time = reload
			if iteration == 1 then    -- it only draw 1 if cast by not divide
				dont_draw_actions = true
			else    --  Mu nerf, so it doesnt restore mana if divided
				mana = mana_
			end
			draw_actions( 1, true )
		end,
	},
	{
		id          = "SIGMA",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 30
			
			local firerate = c.fire_rate_wait
			local reload = current_reload_time
			local mana_ = mana
			
			if ( discarded ~= nil ) then
				for i,data in ipairs( discarded ) do
					local rec = check_recursion( data, recursion_level )
					if ( data ~= nil ) and ( data.type == 1 ) and ( rec > -1 ) then
						dont_draw_actions = true
						data.action( rec )
						dont_draw_actions = false
					end
				end
			end
			
			if ( hand ~= nil ) then
				for i,data in ipairs( hand ) do
					local rec = check_recursion( data, recursion_level )
					if ( data ~= nil ) and ( data.type == 1 ) and ( rec > -1 ) then
						dont_draw_actions = true
						data.action( rec )
						dont_draw_actions = false
					end
				end
			end
			
			if ( deck ~= nil ) then
				for i,data in ipairs( deck ) do
					local rec = check_recursion( data, recursion_level )
					if ( data ~= nil ) and ( data.type == 1 ) and ( rec > -1 ) then
						dont_draw_actions = true
						data.action( rec )
						dont_draw_actions = false
					end
				end
			end
			
			c.fire_rate_wait = firerate
			current_reload_time = reload
			mana = mana_
			if iteration == 1 then    -- it only draw 1 if cast by not divide
				dont_draw_actions = true
			end
			draw_actions( 1, true )
		end,
	},
	{
		id          = "ZETA",
		action 		= function( recursion_level, iteration )
			local entity_id = GetUpdatedEntityID()
			local x, y = EntityGetTransform( entity_id )
			local options = {}
			
			local children = EntityGetAllChildren( entity_id )
			local inventory = EntityGetFirstComponent( entity_id, "Inventory2Component" )
			
			if ( children ~= nil ) and ( inventory ~= nil ) then
				local active_wand = ComponentGetValue2( inventory, "mActiveItem" )
				
				for i,child_id in ipairs( children ) do
					if ( EntityGetName( child_id ) == "inventory_quick" ) then
						local wands = EntityGetAllChildren( child_id )
						
						if ( wands ~= nil ) then
							for k,wand_id in ipairs( wands ) do
								if ( wand_id ~= active_wand ) and EntityHasTag( wand_id, "wand" ) then
									local spells = EntityGetAllChildren( wand_id )
									
									if ( spells ~= nil ) then
										for j,spell_id in ipairs( spells ) do
											local comp = EntityGetFirstComponentIncludingDisabled( spell_id, "ItemActionComponent" )
											
											if ( comp ~= nil ) then
												local action_id = ComponentGetValue2( comp, "action_id" )
												
												table.insert( options, action_id )
											end
										end
									end
								end
							end
						end
					end
				end
			end
			
			if ( #options > 0 ) then
				SetRandomSeed( x + GameGetFrameNum(), y + 251 )
				
				local rnd = Random( 1, #options )
				local action_id = options[rnd]
				
				for i,data in ipairs( actions ) do
					if ( data.id == action_id ) then
						local rec = check_recursion( data, recursion_level )
						if ( rec > -1 ) then
							dont_draw_actions = true
							if iteration == 1 then
								data.action( rec , 1)    --   So you cannot bypass nerf
							else
								data.action( rec )
							end
							dont_draw_actions = false
						end
						break
					end
				end
			end
			if iteration == 1 then    -- it only draw 1 if cast by not divide
				dont_draw_actions = true
			end
			draw_actions( 1, true )
		end,
	},
	{
		id          = "ALPHA",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 15
			
			local data = {}
			
			if ( #discarded > 0 ) then
				data = discarded[1]
			elseif ( #hand > 0 ) then
				data = hand[1]
			elseif ( #deck > 0 ) then
				data = deck[1]
			else
				data = nil
			end
			
			local rec = check_recursion( data, recursion_level )
			
			if ( data ~= nil ) and ( rec > -1 ) then
				if iteration == 1 then
					data.action( rec , 1)    --   So you cannot bypass nerf
				else
					data.action( rec )
				end
			end
			
			--draw_actions( 1, true )   - original code btw
		end,
	},
	{
		id          = "GAMMA",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 15
			
			local data = {}
			
			if ( #deck > 0 ) then
				data = deck[#deck]
			elseif ( #hand > 0 ) then
				data = hand[#hand]
			else
				data = nil
			end
			
			local rec = check_recursion( data, recursion_level )
			
			if ( data ~= nil ) and ( rec > -1 ) then
				if iteration == 1 then
					data.action( rec , 1)    --   So you cannot bypass nerf
				else
					data.action( rec )
				end
			end
			
			--draw_actions( 1, true )
		end,
	},
	{
		id          = "TAU",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 35
			
			local data1 = {}
			local data2 = {}
			
			local s1 = ""
			local s2 = ""
			
			if ( #deck > 0 ) then
				s1 = "deck"
				data1 = deck[1]
			else
				data1 = nil
			end
			
			if ( #deck > 0 ) then
				s2 = "deck 2"
				data2 = deck[2]
			else
				data2 = nil
			end
			
			local rec1 = check_recursion( data1, recursion_level )
			local rec2 = check_recursion( data2, recursion_level )
			
			if ( data1 ~= nil ) and ( rec1 > -1 ) then
				-- print("1: " .. tostring(data1.id) .. ", " .. s1)
				if iteration == 1 then
					data1.action( rec1 , 1)    --   So you cannot bypass nerf
				else
					data1.action( rec1 )
				end
			end
			
			if ( data2 ~= nil ) and ( rec2 > -1 ) then
				-- print("2: " .. tostring(data2.id) .. ", " .. s2)
				if iteration == 1 then
					data2.action( rec2 , 1)    --   So you cannot bypass nerf
				else
					data2.action( rec2 )
				end
			end
			
			--draw_actions( 1, true )
		end,
	},
	{
		id          = "OMEGA",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 50
			
			if ( discarded ~= nil ) then
				for i,data in ipairs( discarded ) do
					local rec = check_recursion( data, recursion_level )
					if ( data ~= nil ) and ( rec > -1 ) and ( data.id ~= "RESET" ) and ( data.id ~= "DIVIDE_2" ) and ( data.id ~= "DIVIDE_3" ) and ( data.id ~= "DIVIDE_4" ) and ( data.id ~= "DIVIDE_10" ) then
						dont_draw_actions = true
						-- omega now cannot copy divides
						if iteration == 1 then
							data.action( rec , 1)    --   So you cannot bypass nerf
						else
							data.action( rec )
						end
						dont_draw_actions = false
					end
				end
			end
			
			if ( hand ~= nil ) then
				for i,data in ipairs( hand ) do
					local rec = check_recursion( data, recursion_level )
					if ( data ~= nil ) and ( ( data.recursive == nil ) or ( data.recursive == false ) ) and ( data.id ~= "DIVIDE_2" ) and ( data.id ~= "DIVIDE_3" ) and ( data.id ~= "DIVIDE_4" ) and ( data.id ~= "DIVIDE_10" ) then
						dont_draw_actions = true
						if iteration == 1 then
							data.action( rec , 1)    --   So you cannot bypass nerf
						else
							data.action( rec )
						end
						dont_draw_actions = false
					end
				end
			end
			
			if ( deck ~= nil ) then
				for i,data in ipairs( deck ) do
					local rec = check_recursion( data, recursion_level )
					if ( data ~= nil ) and ( rec > -1 ) and ( data.id ~= "RESET" ) and ( data.id ~= "DIVIDE_2" ) and ( data.id ~= "DIVIDE_3" ) and ( data.id ~= "DIVIDE_4" ) and ( data.id ~= "DIVIDE_10" ) then
						dont_draw_actions = true
						if iteration == 1 then
							data.action( rec , 1)    --   So you cannot bypass nerf
						else
							data.action( rec )
						end
						dont_draw_actions = false
					end
				end
			end
		end,
	},
	{
		id          = "DRAW_RANDOM",
		action 		= function( recursion_level, iteration )
			SetRandomSeed( GameGetFrameNum() + #deck, GameGetFrameNum() - 325 + #discarded )
			local datasize = #deck + #discarded
			local rnd = Random( 1, datasize )
			
			local data = {}
				
			if ( rnd <= #deck ) then
				data = deck[rnd]
			else
				data = discarded[rnd - #deck]
			end
			
			local checks = 0
			local rec = check_recursion( data, recursion_level )
			
			while ( data ~= nil ) and ( ( rec == -1 ) or ( ( data.uses_remaining ~= nil ) and ( data.uses_remaining == 0 ) ) ) and ( checks < datasize ) do
				rnd = ( rnd % datasize ) + 1
				checks = checks + 1
				
				if ( rnd <= #deck ) then
					data = deck[rnd]
				else
					data = discarded[rnd - #deck]
				end
				
				rec = check_recursion( data, recursion_level )
			end
			
			if ( data ~= nil ) and ( rec > -1 ) and ( ( data.uses_remaining == nil ) or ( data.uses_remaining ~= 0 ) ) then
				
				if iteration == 1 then
					data.action( rec , 1)    --   So you cannot bypass nerf
				else
					data.action( rec )
				end
				
				if ( data.uses_remaining ~= nil ) and ( data.uses_remaining > 0 ) then
					data.uses_remaining = data.uses_remaining - 1
					
					local reduce_uses = ActionUsesRemainingChanged( data.inventoryitem_id, data.uses_remaining )
					if not reduce_uses then
						data.uses_remaining = data.uses_remaining + 1 -- cancel the reduction
					end
				end
			end
		end,
	},
	{
		id          = "DRAW_RANDOM_X3",
		action 		= function( recursion_level, iteration )
			SetRandomSeed( GameGetFrameNum() + #deck, GameGetFrameNum() - 325 + #discarded )
			local datasize = #deck + #discarded
			local rnd = Random( 1, datasize )
			
			local data = {}
				
			if ( rnd <= #deck ) then
				data = deck[rnd]
			else
				data = discarded[rnd - #deck]
			end
			
			local checks = 0
			local rec = check_recursion( data, recursion_level )
			
			while ( data ~= nil ) and ( ( rec == -1 ) or ( ( data.uses_remaining ~= nil ) and ( data.uses_remaining == 0 ) ) ) and ( checks < datasize ) do
				rnd = ( rnd % datasize ) + 1
				checks = checks + 1
				
				if ( rnd <= #deck ) then
					data = deck[rnd]
				else
					data = discarded[rnd - #deck]
				end
				
				rec = check_recursion( data, recursion_level )
			end
			
			if ( data ~= nil ) and ( rec > -1 ) and ( ( data.uses_remaining == nil ) or ( data.uses_remaining ~= 0 ) ) then
				for i=1,3 do
					if iteration == 1 then
						data.action( rec , 1)    --   So you cannot bypass nerf
					else
						data.action( rec )
					end
				end
				
				if ( data.uses_remaining ~= nil ) and ( data.uses_remaining > 0 ) then
					data.uses_remaining = data.uses_remaining - 1
					
					local reduce_uses = ActionUsesRemainingChanged( data.inventoryitem_id, data.uses_remaining )
					if not reduce_uses then
						data.uses_remaining = data.uses_remaining + 1 -- cancel the reduction
					end
				end
			end
		end,
	},
	{
		id          = "DRAW_3_RANDOM",
		action 		= function( recursion_level, iteration )
			SetRandomSeed( GameGetFrameNum() + #deck, GameGetFrameNum() - 325 + #discarded )
			local datasize = #deck + #discarded
			
			for i=1,3 do
				local rnd = Random( 1, datasize )
				
				local data = {}
				
				if ( rnd <= #deck ) then
					data = deck[rnd]
				else
					data = discarded[rnd - #deck]
				end
				
				local checks = 0
				local rec = check_recursion( data, recursion_level )
				
				while ( data ~= nil ) and ( ( rec == -1 ) or ( ( data.uses_remaining ~= nil ) and ( data.uses_remaining == 0 ) ) ) and ( checks < datasize ) do
					rnd = ( rnd % datasize ) + 1
					checks = checks + 1
					
					if ( rnd <= #deck ) then
						data = deck[rnd]
					else
						data = discarded[rnd - #deck]
					end
					
					rec = check_recursion( data, recursion_level )
				end
				
				if ( data ~= nil ) and ( rec > -1 ) and ( ( data.uses_remaining == nil ) or ( data.uses_remaining ~= 0 ) ) then
					if iteration == 1 then
						data.action( rec , 1)    --   So you cannot bypass nerf
					else
						data.action( rec )
					end
					
					if ( data.uses_remaining ~= nil ) and ( data.uses_remaining > 0 ) then
						data.uses_remaining = data.uses_remaining - 1
						
						local reduce_uses = ActionUsesRemainingChanged( data.inventoryitem_id, data.uses_remaining )
						if not reduce_uses then
							data.uses_remaining = data.uses_remaining + 1 -- cancel the reduction
						end
					end
				end
			end
		end,
	}
}
-- Change spells
for i=1, #actions do
	for d=1, #Simple_divides do
		if Simple_divides[d]["id"] == actions[i]["id"] then
			actions[i]["action"] = Simple_divides[d]["action"]
		end
	end
end