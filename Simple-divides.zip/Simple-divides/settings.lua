dofile("data/scripts/lib/mod_settings.lua")

local mod_id = "Simple_divides"
local mod_settings_version = 1
local mod_settings = {
				{
			id = "Mu_nerf",
			ui_name = [[Mu on "damage from mana" nerf]],
			ui_description = [[Disables mana restore from Mu.
Better for balance.]],
			value_default = true,
			scope = MOD_SETTING_SCOPE_RUNTIME
				},
				{
			id = "greek_spell_changes",
			ui_name = "Change greek spells",
			ui_description = [[Next Greek letters settings will apply. 
Turn off if some mods changes greeks]],
			value_default = true,
			scope = MOD_SETTING_SCOPE_RUNTIME
					}, 
					{
				category_id = "greek_spells",
				ui_name = "Greek spells changes",
				ui_description = "Greek spells changes",
				foldable = true,
				_folded = true, -- this field will be automatically added to each category table to store the current folding state
				settings = {
					{
						id = "greek_spell_casting",
						ui_name = "Greek spells casting fix",
						ui_description = [[Some greek spells doesnt draw on their own if divided]],
						value_default = true,
						scope = MOD_SETTING_SCOPE_RUNTIME
					},
					{
						id = "Greek_Mu_fix",
						ui_name = "Greek spells doesnt bypass Mu nerf",
						ui_description = [[Prevents Mu nerf bypass, using divide to greek spell to Mu]],
						value_default = true,
						scope = MOD_SETTING_SCOPE_RUNTIME
					},
					{
						id = "Omega_fix",
						ui_name = "Fix omega with divides",
						ui_description = [[Omega cannot copy divides.
Thats will be intuitive and not confusing]],
						value_default = true,
						scope = MOD_SETTING_SCOPE_RUNTIME
					}
							},
							},
	}

function ModSettingsUpdate(init_scope)
    local old_version = mod_settings_get_version(mod_id)
    mod_settings_update(mod_id, mod_settings, init_scope)
end

function ModSettingsGuiCount()
	return mod_settings_gui_count( mod_id, mod_settings )
end

function ModSettingsGui( gui, in_main_menu )
	mod_settings_gui( mod_id, mod_settings, gui, in_main_menu )
end
